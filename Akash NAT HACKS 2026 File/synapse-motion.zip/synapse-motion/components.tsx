"use client";
import { Children, cloneElement, isValidElement, useEffect, useRef, useState, type ReactElement, type ReactNode, type RefObject } from "react";

export function useReducedMotion() {
  const [r, setR] = useState(false);
  useEffect(() => {
    const m = matchMedia("(prefers-reduced-motion: reduce)");
    setR(m.matches); const f = () => setR(m.matches);
    m.addEventListener("change", f); return () => m.removeEventListener("change", f);
  }, []);
  return r;
}

/* 3. Voice level bars + word-by-word reveal */
export function VoiceBars({ active = true }: { active?: boolean }) {
  const r = useReducedMotion();
  return (
    <span className="sx-bars" aria-hidden style={{ color: "#2d5f8b" }}>
      {[0, 1, 2, 3, 4].map(i => <i key={i} style={{ animationDelay: `${i * 120}ms`, animationPlayState: active && !r ? "running" : "paused", transform: active ? undefined : "scaleY(.3)" }} />)}
    </span>
  );
}
export function WordReveal({ text, lang, dir, stagger = 70, className = "" }: { text: string; lang?: string; dir?: "ltr" | "rtl"; stagger?: number; className?: string }) {
  const parts: string[] = typeof Intl !== "undefined" && "Segmenter" in Intl
    ? Array.from(new (Intl as any).Segmenter(lang, { granularity: "word" }).segment(text), (s: any) => s.segment)
    : text.split(/(\s+)/);
  let n = 0;
  return (
    <span lang={lang} dir={dir} className={className}>
      {parts.map((p, i) => /^\s+$/.test(p) ? p : <span key={i} className="sx-word" style={{ animationDelay: `${n++ * stagger}ms` }}>{p}</span>)}
    </span>
  );
}

/* 4. EKG loader (replaces the spinner while translating) */
export function EkgLoader({ label = "Translating" }: { label?: string }) {
  const d = "M0 20H58l6-7 6 7h6l7-17 8 34 7-17h8l5-5 5 5H200";
  return (
    <div role="status" style={{ display: "flex", alignItems: "center", gap: 12, font: "600 1.125rem Figtree,system-ui", color: "#4a6380" }}>
      <svg viewBox="0 0 200 40" width="120" height="24" fill="none" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <path d={d} pathLength={1} stroke="#d5e0eb" />
        <path d={d} pathLength={1} stroke="#2d5f8b" className="sx-ekg-live" />
      </svg>{label}
    </div>
  );
}

/* 1. Translation flow: patient phrases fly into the clinician summary fields */
type Item = { from: string; to: string; label: string; lang?: string; dir?: "ltr" | "rtl" };
export function TranslationFlow({ items, playKey }: { items: Item[]; playKey: number }) {
  const root = useRef<HTMLDivElement>(null);
  const src = useRef<(HTMLElement | null)[]>([]), dst = useRef<(HTMLElement | null)[]>([]);
  const [shown, setShown] = useState<boolean[]>(() => items.map(() => false));
  const reduced = useReducedMotion();
  useEffect(() => {
    setShown(items.map(() => reduced));
    if (reduced || !playKey || !root.current) return;
    const r = root.current.getBoundingClientRect(), anims: Animation[] = [], clones: HTMLElement[] = [];
    items.forEach((it, i) => {
      const a = src.current[i]!.getBoundingClientRect(), b = dst.current[i]!.getBoundingClientRect();
      const c = document.createElement("span"); c.className = "sx-fly"; c.textContent = it.from;
      if (it.lang) c.lang = it.lang; c.dir = it.dir ?? "ltr";
      c.style.left = a.left - r.left + "px"; c.style.top = a.top - r.top + "px";
      root.current!.appendChild(c); clones.push(c);
      const t = `translate(${b.left - a.left}px,${b.top - a.top}px)`;
      const an = c.animate([{ transform: "none", opacity: 1 }, { transform: `${t} scale(.92)`, opacity: 1, offset: .78 }, { transform: `${t} scale(.92)`, opacity: 0 }],
        { duration: 1100, delay: i * 380, easing: "cubic-bezier(.16,1,.3,1)", fill: "both" });
      an.onfinish = () => { c.remove(); setShown(s => s.map((v, j) => j === i || v)); };
      anims.push(an);
    });
    return () => { anims.forEach(a => a.cancel()); clones.forEach(c => c.remove()); };
  }, [playKey]); // eslint-disable-line
  return (
    <div ref={root} style={{ position: "relative", display: "grid", gap: 24, gridTemplateColumns: "1fr 1fr" }}>
      <div className="sx-bubble sx-bubble-patient" style={{ display: "flex", flexWrap: "wrap", gap: 8, alignContent: "start" }}>
        {items.map((it, i) => <span key={i} ref={e => { src.current[i] = e; }} lang={it.lang} dir={it.dir} style={{ opacity: shown[i] || !playKey ? 1 : .25, transition: "opacity .4s" }}>{it.from}</span>)}
      </div>
      <div style={{ background: "#101e34", borderRadius: "2rem", padding: 20, display: "grid", gap: 12, borderEndEndRadius: ".5rem" }}>
        {items.map((it, i) => (
          <div key={i} className="sx-field" ref={e => { dst.current[i] = e; }}>
            <small>{it.label}</small>
            {shown[i] ? <WordReveal text={it.to} stagger={60} /> : <span style={{ color: "#4a6380" }}>…</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

/* 2. "Session cleared" particle dissolve */
export function ClearDissolve({ active, onDone, children }: { active: boolean; onDone?: () => void; children: ReactNode }) {
  const box = useRef<HTMLDivElement>(null), cv = useRef<HTMLCanvasElement>(null), reduced = useReducedMotion();
  useEffect(() => {
    if (!active) return;
    if (reduced) { const t = setTimeout(() => onDone?.(), 300); return () => clearTimeout(t); }
    const { width: w, height: h } = box.current!.getBoundingClientRect(), c = cv.current!, d = devicePixelRatio || 1;
    c.width = w * d; c.height = h * d; const g = c.getContext("2d")!; g.scale(d, d);
    const cols = ["#101e34", "#77a0c4", "#2d5f8b", "#e6eef6"];
    const P = Array.from({ length: Math.min(700, Math.floor(w * h / 450)) }, () => ({ x: Math.random() * w, y: Math.random() * h, vx: 30 + Math.random() * 90, vy: -20 - Math.random() * 60, r: 1 + Math.random() * 2.2, c: cols[Math.random() * 4 | 0], dl: Math.random() * .5 }));
    const T = 1700, s = performance.now(); let raf = 0;
    const f = (n: number) => {
      const t = n - s; g.clearRect(0, 0, w, h);
      for (const p of P) {
        const k = Math.min(Math.max((t / T - p.dl) / (1 - p.dl), 0), 1);
        g.globalAlpha = 1 - k; g.fillStyle = p.c; g.beginPath(); g.arc(p.x + p.vx * k * 1.3, p.y + p.vy * k * 1.3, p.r, 0, 7); g.fill();
      }
      if (t < T) raf = requestAnimationFrame(f); else onDone?.();
    };
    raf = requestAnimationFrame(f); return () => cancelAnimationFrame(raf);
  }, [active]); // eslint-disable-line
  return (
    <div ref={box} className={active ? "sx-dissolve" : ""} style={{ position: "relative" }}>
      <div className="sx-content">{children}</div>
      <canvas ref={cv} aria-hidden style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", display: active && !reduced ? "block" : "none" }} />
    </div>
  );
}

/* 5. Back-translation match sweep + check */
export function MatchSweep({ original, back, matched, lang, dir }: { original: string; back: string; matched: boolean; lang?: string; dir?: "ltr" | "rtl" }) {
  return (
    <div style={{ display: "grid", gap: 12 }}>
      {[["Patient's words", original, true], ["Read back", back, false]].map(([cap, txt, isP], i) => (
        <div key={i} className={`sx-bubble ${isP ? "sx-bubble-patient" : "sx-bubble-read"}`} style={{ position: "relative", overflow: "hidden" }}>
          <small style={{ display: "block", font: "500 .875rem 'Noto Sans',system-ui", color: "#4a6380" }}>{cap as string}</small>
          <span lang={isP ? lang : undefined} dir={isP ? dir : undefined}>{txt as string}</span>
          {matched && <span key={String(matched)} className="sx-sweep" style={{ position: "absolute", inset: 0, animationDelay: `${i * 160}ms` }} aria-hidden />}
        </div>
      ))}
      {matched && (
        <div className="sx-pop" style={{ display: "inline-flex", gap: 8, alignItems: "center", color: "#1f4a70", font: "600 1rem Figtree,system-ui" }}>
          <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#2d5f8b" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" fill="#e6eef6" /><path d="M7 12.5l3.2 3.2L17 9" pathLength={1} className="sx-draw" style={{ animationDelay: ".25s" }} /></svg>
          Read back to the patient and confirmed
        </div>
      )}
    </div>
  );
}

/* 6. RTL mirror via View Transitions (use logical CSS properties so layout flips) */
export function useDirTransition(target: RefObject<HTMLElement | null>) {
  const r = useReducedMotion();
  return (dir: "ltr" | "rtl") => {
    const set = () => { if (target.current) target.current.dir = dir; };
    const d: any = document; if (d.startViewTransition && !r) d.startViewTransition(set); else set();
  };
}

/* 7. Pictogram tile: stroke redraws on select */
export function PictogramTile({ label, selected, onClick, children }: { label: string; selected: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" aria-pressed={selected} onClick={onClick} className={`sx-tile ${selected ? "sx-pop" : ""}`}>
      <svg key={String(selected)} viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        {Children.map(children, c => isValidElement(c) ? cloneElement(c as ReactElement<any>, { pathLength: 1, className: selected ? "sx-draw" : undefined }) : c)}
      </svg>
      <span>{selected && "✓ "}{label}</span>
    </button>
  );
}

/* 8. Body diagram ripple + pain ring */
const REGIONS: Record<string, string> = { head: "M50 8a11 11 0 1 0 .1 0Z", chest: "M33 28h34l3 36H30Z", "left arm": "M30 30l-12 44 8 2 10-34Z", "right arm": "M70 30l12 44-8 2-10-34Z", legs: "M34 66h32l-4 42H52l-2-24-2 24H38Z" };
export function BodyDiagram({ onPick }: { onPick?: (r: string) => void }) {
  const [sel, setSel] = useState<string>(), [rip, setRip] = useState<{ id: number; x: number; y: number }[]>([]);
  const pick = (name: string, e: React.PointerEvent<SVGPathElement>) => {
    const s = (e.currentTarget.ownerSVGElement as SVGSVGElement), pt = s.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY;
    const p = pt.matrixTransform(s.getScreenCTM()!.inverse()), id = Date.now();
    setSel(name); onPick?.(name); setRip(r => [...r, { id, x: p.x, y: p.y }]); setTimeout(() => setRip(r => r.filter(q => q.id !== id)), 850);
  };
  return (
    <svg viewBox="0 0 100 116" width="100%" style={{ maxWidth: 260 }} role="group" aria-label="Body diagram">
      {Object.entries(REGIONS).map(([n, d]) => (
        <path key={n} d={d} tabIndex={0} role="button" aria-pressed={sel === n} aria-label={n} onPointerDown={e => pick(n, e)}
          onKeyDown={e => (e.key === "Enter" || e.key === " ") && setSel(n)}
          fill={sel === n ? "#2d5f8b" : "#e6eef6"} stroke="#2d5f8b" strokeWidth="2" strokeLinejoin="round" style={{ transition: "fill .25s", cursor: "pointer", outline: "none" }} />
      ))}
      {rip.map(r => <circle key={r.id} cx={r.x} cy={r.y} r="16" fill="none" stroke="#77a0c4" strokeWidth="2" className="sx-ripple" pointerEvents="none" />)}
    </svg>
  );
}
export function PainScale({ value, onChange }: { value: number; onChange: (n: number) => void }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
      <svg viewBox="0 0 44 44" width="72" height="72" aria-hidden><circle cx="22" cy="22" r="18" fill="none" stroke="#d5e0eb" strokeWidth="4" />
        <circle cx="22" cy="22" r="18" fill="none" stroke="#2d5f8b" strokeWidth="4" strokeLinecap="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - value / 5} transform="rotate(-90 22 22)" style={{ transition: "stroke-dashoffset .6s cubic-bezier(.16,1,.3,1)" }} /></svg>
      <div style={{ display: "flex", gap: 8 }}>{[1, 2, 3, 4, 5].map(n => (
        <button key={n} type="button" aria-pressed={value === n} aria-label={`Pain ${n} of 5`} onClick={() => onChange(n)}
          className={value === n ? "sx-pop" : ""} style={{ width: 56, height: 56, borderRadius: 9999, border: "1px solid #d5e0eb", background: value === n ? "#2d5f8b" : "#fff", color: value === n ? "#fff" : "#101e34", font: "700 1.5rem Figtree,system-ui" }}>{n}</button>))}
      </div>
    </div>
  );
}

/* 9. Logo mark draw-on. Placeholder swooshes: swap the two <path d> for the real SynapseMark paths. */
export function LogoDrawOn({ size = 120 }: { size?: number }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} fill="none" strokeWidth="9" strokeLinecap="round" role="img" aria-label="Synapse" style={{ background: "#101e34", borderRadius: 24, padding: 12 }}>
      <path d="M72 24C60 10 30 12 30 32C30 52 62 46 62 66" pathLength={1} stroke="#fff" className="sx-draw" style={{ animationDuration: "1.1s" }} />
      <path d="M28 76C40 90 70 88 70 68C70 48 38 54 38 34" pathLength={1} stroke="#77a0c4" className="sx-draw" style={{ animationDuration: "1.1s", animationDelay: ".35s" }} />
    </svg>
  );
}

/* 10. Signal pulse: a dot carries the message from patient to clinician */
export function SignalPulse({ loop = true }: { loop?: boolean }) {
  const r = useReducedMotion(), d = "M16 50C70 -10 130 -10 184 50";
  return (
    <svg viewBox="0 0 200 60" width="100%" style={{ maxWidth: 360 }} aria-hidden fill="none">
      <path d={d} pathLength={1} stroke="#d5e0eb" strokeWidth="2" strokeDasharray="4 5" />
      <circle cx="16" cy="50" r="7" fill="#e6eef6" stroke="#2d5f8b" strokeWidth="2" /><circle cx="184" cy="50" r="7" fill="#101e34" />
      {r ? <circle cx="184" cy="50" r="4" fill="#77a0c4" /> : (
        <circle r="5" fill="#2d5f8b">
          <animateMotion dur="1.8s" repeatCount={loop ? "indefinite" : "1"} path={d} fill="freeze" keyPoints="0;1" keyTimes="0;1" calcMode="spline" keySplines=".16 1 .3 1" />
          <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.1;.85;1" dur="1.8s" repeatCount={loop ? "indefinite" : "1"} />
        </circle>)}
    </svg>
  );
}

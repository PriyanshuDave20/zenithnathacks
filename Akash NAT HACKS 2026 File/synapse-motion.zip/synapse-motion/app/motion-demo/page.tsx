"use client";
import { useRef, useState } from "react";
import "../../motion.css";
import { BodyDiagram, ClearDissolve, EkgLoader, LogoDrawOn, MatchSweep, PainScale, PictogramTile, SignalPulse, TranslationFlow, VoiceBars, WordReveal, useDirTransition } from "../../components";

const Sec = ({ t, children }: { t: string; children: React.ReactNode }) => <section style={{ margin: "48px 0" }}><h2 style={{ font: "700 1.5rem Figtree,system-ui", marginBottom: 16 }}>{t}</h2>{children}</section>;
const Btn = (p: React.ButtonHTMLAttributes<HTMLButtonElement>) => <button type="button" {...p} style={{ height: 44, padding: "0 20px", borderRadius: 9999, border: "1px solid #d5e0eb", color: "#1f4a70", font: "600 1rem Figtree,system-ui", background: "#fff", marginTop: 12 }} />;

export default function Demo() {
  const [play, setPlay] = useState(0), [gone, setGone] = useState(false), [clearing, setClearing] = useState(false);
  const [sel, setSel] = useState<string>(), [pain, setPain] = useState(3), [ok, setOk] = useState(false), [wk, setWk] = useState(0), [talk, setTalk] = useState(true);
  const frame = useRef<HTMLDivElement>(null), setDir = useDirTransition(frame);
  return (
    <main style={{ maxWidth: 880, margin: "0 auto", padding: 24, font: "400 1.125rem 'Noto Sans',system-ui", color: "#101e34" }}>
      <Sec t="9 · Logo draw-on"><LogoDrawOn key={wk} /><Btn onClick={() => setWk(k => k + 1)}>Replay</Btn></Sec>
      <Sec t="3 · Voice → words">
        <VoiceBars active={talk} /> <Btn onClick={() => { setTalk(t => !t); setWk(k => k + 1); }}>{talk ? "Stop" : "Listen"}</Btn>
        <div className="sx-bubble sx-bubble-patient" style={{ marginTop: 12 }}><WordReveal key={wk} text="I have had chest pain since yesterday morning." /></div>
      </Sec>
      <Sec t="4 · EKG loader"><EkgLoader /></Sec>
      <Sec t="1 · Translation flow">
        <TranslationFlow playKey={play} items={[
          { from: "Dolor en el pecho", to: "Chest pain", label: "Chief complaint", lang: "es" },
          { from: "desde ayer", to: "Since yesterday", label: "Duration", lang: "es" },
          { from: "me falta el aire", to: "Short of breath", label: "Symptoms", lang: "es" }]} />
        <Btn onClick={() => setPlay(p => p + 1)}>Play translation</Btn>
      </Sec>
      <Sec t="5 · Back-translation match"><MatchSweep original="Dolor en el pecho desde ayer" back="Chest pain since yesterday" matched={ok} lang="es" /><Btn onClick={() => setOk(o => !o)}>Toggle match</Btn></Sec>
      <Sec t="6 · RTL mirror">
        <div ref={frame} dir="ltr" style={{ display: "grid", gap: 12 }}>
          <div className="sx-bubble sx-bubble-patient" style={{ marginInlineEnd: "20%" }}>Patient bubble (tail follows direction)</div>
          <div className="sx-bubble sx-bubble-clin" style={{ marginInlineStart: "20%" }}>Clinician bubble</div>
        </div>
        <Btn onClick={() => setDir("rtl")}>Arabic (RTL)</Btn> <Btn onClick={() => setDir("ltr")}>English (LTR)</Btn>
      </Sec>
      <Sec t="7 · Pictogram select">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
          <PictogramTile label="Fever" selected={sel === "f"} onClick={() => setSel("f")}><path d="M14 14.8V4a2 2 0 0 0-4 0v10.8a4 4 0 1 0 4 0Z" /><path d="M18 6h3M18 10h3" /></PictogramTile>
          <PictogramTile label="Breath" selected={sel === "b"} onClick={() => setSel("b")}><path d="M3 8h11a3 3 0 1 0-3-3" /><path d="M3 12h16a3 3 0 1 1-3 3" /><path d="M3 16h7" /></PictogramTile>
          <PictogramTile label="Clock" selected={sel === "c"} onClick={() => setSel("c")}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></PictogramTile>
        </div>
      </Sec>
      <Sec t="8 · Body ripple + pain ring"><BodyDiagram /><div style={{ marginTop: 16 }}><PainScale value={pain} onChange={setPain} /></div></Sec>
      <Sec t="10 · Signal pulse"><SignalPulse /></Sec>
      <Sec t="2 · Session cleared dissolve">
        {!gone && <ClearDissolve active={clearing} onDone={() => setGone(true)}>
          <div className="sx-bubble sx-bubble-clin" style={{ borderRadius: "2rem" }}>Chief complaint: chest pain since yesterday. Symptoms: short of breath.</div>
        </ClearDissolve>}
        {gone && <p className="sx-arrive" style={{ font: "700 2.25rem Figtree,system-ui" }}>Session cleared</p>}
        <Btn onClick={() => { setGone(false); setClearing(false); }}>Reset</Btn> <Btn onClick={() => setClearing(true)}>End and clear</Btn>
      </Sec>
    </main>
  );
}
